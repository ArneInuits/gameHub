
public class Settings {
	public Settings() {
		
	}
	public void setValue(int value) {
		
	}
}
